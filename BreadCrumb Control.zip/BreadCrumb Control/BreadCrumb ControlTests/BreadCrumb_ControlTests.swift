//
//  BreadCrumb_ControlTests.swift
//  BreadCrumb ControlTests
//
//  Created by Philippe K on 22/11/2015.
//  Copyright © 2015 Philippe K. All rights reserved.
//

import XCTest
@testable import BreadCrumb_Control

class BreadCrumb_ControlTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
